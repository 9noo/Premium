// --- Animation.js ---

// 1. تأثير الكتابة التلقائية (من المرحلة الأولى)
export function initTypingEffect() {
    const element = document.getElementById('typing-text');
    const words = [
        "أهلاً بك! أنا نور الدين، مطور برمجيات وأتمتة من العراق.",
        "شغوف بهندسة الهاردوير وإدارة تبريد المعالجات.",
        "أقوم ببناء ثيمات متكاملة وحزم MIUI المخصصة.",
        "مختص بتجاوز معايير ضغط محتوى إنستغرام عبر MetaConfig."
    ];
    
    let wordIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let currentWord = '';

    function type() {
        currentWord = words[wordIndex];
        
        if (isDeleting) {
            charIndex--;
        } else {
            charIndex++;
        }

        element.textContent = currentWord.substring(0, charIndex);

        let typeSpeed = 80;

        if (isDeleting) {
            typeSpeed /= 2;
        }

        if (!isDeleting && charIndex === currentWord.length) {
            typeSpeed = 2000;
            isDeleting = true;
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            wordIndex = (wordIndex + 1) % words.length;
            typeSpeed = 500;
        }

        setTimeout(type, typeSpeed);
    }

    if (element) type();
}

// 2. مراقب التمرير لإظهار العناصر بنعومة (Intersection Observer)
export function initScrollReveal() {
    const revealElements = document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right, .reveal-scale');
    
    const observerOptions = {
        root: null,
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target); // تشغيل الحركة مرة واحدة فقط لزيادة كفاءة الأداء
            }
        });
    }, observerOptions);

    revealElements.forEach(el => observer.observe(el));
}
