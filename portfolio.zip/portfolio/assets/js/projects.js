// --- projects.js ---
import { projectsData } from '../data/projects.js';
import { openModal } from './modal.js';

export function initProjects() {
    const grid = document.getElementById('projects-grid');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const searchInput = document.getElementById('project-search');

    if (!grid) return;

    // 1. دالة توليد كروت المشاريع ديناميكياً
    function renderProjects(projectsToRender) {
        grid.innerHTML = ''; // تفريغ الشبكة أولاً

        if (projectsToRender.length === 0) {
            grid.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fa-solid fa-folder-open text-4xl mb-4 block"></i>
                    <p>لم يتم العثور على أي مشروع يطابق بحثك.</p>
                </div>
            `;
            return;
        }

        projectsToRender.forEach(project => {
            const card = document.createElement('div');
            card.className = "project-card glass rounded-2xl border border-white/5 overflow-hidden group hover:border-emerald-500/20 transition-all duration-300 flex flex-col justify-between cursor-pointer reveal-scale active";
            card.setAttribute('data-id', project.id);

            // تحويل التقنيات لأول 3 تاغات فقط للكروت لجمالية التصميم
            const techTags = project.tech.slice(0, 3).map(t => 
                `<span class="text-[10px] font-mono px-2 py-1 rounded bg-white/5 border border-white/5 text-gray-400">${t}</span>`
            ).join('');

            card.innerHTML = `
                <div class="p-6 space-y-4">
                    <div class="flex justify-between items-start">
                        <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                            <i class="fa-solid fa-cube text-lg"></i>
                        </div>
                        <span class="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full">
                            ${project.category === 'python' ? 'بايثون وأتمتة' : project.category === 'customization' ? 'تخصيص' : 'ويب'}
                        </span>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">${project.title}</h3>
                        <p class="text-gray-400 text-xs leading-relaxed mt-2 line-clamp-3">${project.shortDescription}</p>
                    </div>
                </div>
                <div class="p-6 border-t border-white/5 flex items-center justify-between bg-black/10">
                    <div class="flex gap-1.5">${techTags}</div>
                    <span class="text-xs text-emerald-400 group-hover:translate-x-[-4px] transition-transform flex items-center gap-1 font-bold">
                        تفاصيل <i class="fa-solid fa-arrow-left text-[10px]"></i>
                    </span>
                </div>
            `;

            // عند الضغط على الكارت يتم فتح المودال المخصص
            card.addEventListener('click', () => {
                openModal(project.id);
            });

            grid.appendChild(card);
        });
    }

    // عرض جميع المشاريع عند التحميل لأول مرة
    renderProjects(projectsData);

    // 2. نظام فلترة المشاريع بالتصنيف
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // تحديث حالة الأزرار النشطة بصرياً
            filterButtons.forEach(btn => btn.classList.remove('active', 'bg-emerald-500', 'text-white'));
            filterButtons.forEach(btn => btn.classList.add('text-gray-400', 'hover:text-white', 'hover:bg-white/5'));
            
            button.classList.add('active', 'bg-emerald-500', 'text-white');
            button.classList.remove('text-gray-400', 'hover:text-white', 'hover:bg-white/5');

            filterAndSearch();
        });
    });

    // 3. فلترة المشاريع بالبحث النصي
    searchInput.addEventListener('input', () => {
        filterAndSearch();
    });

    // دالة مدمجة للفلترة المزدوجة (تصنيف + بحث) معاً بكفاءة عالية
    function filterAndSearch() {
        const activeCategory = document.querySelector('.filter-btn.active').getAttribute('data-filter');
        const searchQuery = searchInput.value.toLowerCase().trim();

        const filtered = projectsData.filter(project => {
            const matchesCategory = activeCategory === 'all' || project.category === activeCategory;
            const matchesSearch = project.title.toLowerCase().includes(searchQuery) || 
                                  project.shortDescription.toLowerCase().includes(searchQuery) ||
                                  project.tech.some(t => t.toLowerCase().includes(searchQuery));
            return matchesCategory && matchesSearch;
        });

        // إضافة تأثير انيميشن خفيف عند إعادة التحميل
        grid.style.opacity = '0';
        setTimeout(() => {
            renderProjects(filtered);
            grid.style.opacity = '1';
        }, 150);
    }
}
