// --- Cursor.js ---
export function initCursorGlow() {
    const cursor = document.getElementById('custom-cursor');
    const glow = document.getElementById('cursor-glow');
    
    if (!cursor || !glow) return;

    window.addEventListener('mousemove', (e) => {
        const posX = e.clientX;
        const posY = e.clientY;
        
        // تحريك العناصر بمرونة تتبع الماوس
        cursor.style.transform = `translate3d(${posX}px, ${posY}px, 0)`;
        glow.style.transform = `translate3d(${posX}px, ${posY}px, 0)`;
    });

    // تفاعل الـ Cursor مع العناصر القابلة للنقر (Interactive Elements)
    const interactives = document.querySelectorAll('a, button, [role="button"]');
    
    interactives.forEach(el => {
        el.addEventListener('mouseenter', () => {
            cursor.classList.add('scale-150', 'border-emerald-400');
            glow.style.width = '150px';
            glow.style.height = '150px';
        });
        el.addEventListener('mouseleave', () => {
            cursor.classList.remove('scale-150', 'border-emerald-400');
            glow.style.width = '384px'; // الحجم الأصلي للـ Tailwind w-96
            glow.style.height = '384px';
        });
    });
}
