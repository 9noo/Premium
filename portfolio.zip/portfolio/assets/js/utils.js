/* ==========================================================================
   Utils.js - وظائف التحكم والتفاعل الديناميكي للموقع
   ========================================================================== */

// 1. القائمة الجانبية للهواتف (Mobile Menu Toggle)
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

// 2. تصفية المشاريع حسب التصنيف (Project Filter Logic)
function filterProjects(category) {
    const cards = document.querySelectorAll('.project-card');
    const tabs = document.querySelectorAll('.project-tab');
    
    // تغيير مظهر التبويب النشط ليعطي انطباعاً بالتحديد
    tabs.forEach(tab => {
        tab.classList.remove('bg-emerald-500/10', 'text-emerald-400');
    });
    
    if (event && event.currentTarget) {
        event.currentTarget.classList.add('bg-emerald-500/10', 'text-emerald-400');
    }

    cards.forEach(card => {
        if (category === 'all' || card.getAttribute('data-category') === category) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
}

// 3. محاكي الأوامر التفاعلي للمختبر البرمجي (Interactive Terminal Logic)
function runCommand(command) {
    const terminalBody = document.getElementById('terminal-body');
    if (!terminalBody) return;
    
    let output = '';

    if (command === 'bot') {
        output = `
<div class="text-gray-500">[System] Initializing telegram_bot_runner.py...</div>
<div class="text-yellow-400">[Log] Loading API Tokens secure configuration...</div>
<div class="text-white">&gt;&gt;&gt; bot = python_telegram_bot.create(token="Nour_IQ_Bot")</div>
<div class="text-white">&gt;&gt;&gt; bot.add_inline_keyboards(sections=7)</div>
<div class="text-emerald-400">[Success] Bot running safely in 60 FPS transition! Inline Keyboards loaded.</div>
        `;
    } else if (command === 'instagram') {
        output = `
<div class="text-gray-500">[System] Overriding MetaConfig parameters...</div>
<div class="text-cyan-400">[Config] Set img_quality_bonus = True</div>
<div class="text-cyan-400">[Config] Set target_fps = 60</div>
<div class="text-white">&gt;&gt;&gt; instagram_core.apply_compression_bypass()</div>
<div class="text-emerald-400">[Success] Bypass activated! High definition metadata bypass enabled for account.</div>
        `;
    } else if (command === 'thermal') {
        output = `
<div class="text-gray-500">[Hardware] Measuring cooling fan airflow rate...</div>
<div class="text-purple-400">[Data] Cooling Pad Speed: 5400 RPM</div>
<div class="text-white">&gt;&gt;&gt; thermal_engine.calculate_exhaust_rate()</div>
<div class="text-emerald-400">[Output] Core temperature dropped from 86°C to 74°C under peak game loading.</div>
        `;
    }

    terminalBody.innerHTML = `
        <div class="text-gray-500">[NourEldin Sandbox 2026] Running terminal environment.</div>
        ${output}
        <div class="text-gray-300">$ _</div>
    `;
    terminalBody.scrollTop = terminalBody.scrollHeight;
}

// 4. التحكم بالنوافذ المنبثقة لعرض تفاصيل المشاريع (Modal Triggers)
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('hidden');
    }
}

// 5. معالجة نموذج الاتصال (Form Handling)
function handleFormSubmit(event) {
    event.preventDefault();
    const successMessage = document.getElementById('form-success');
    if (successMessage) {
        successMessage.classList.remove('hidden');
        event.target.reset();
        setTimeout(() => {
            successMessage.classList.add('hidden');
        }, 6000);
    }
}

// 6. تبديل الألوان والسمات ديناميكياً (Dynamic Color Themes Toggle)
let currentTheme = 'emerald';
function toggleTheme() {
    const root = document.documentElement;
    const themeIcon = document.getElementById('theme-icon');
    
    if (currentTheme === 'emerald') {
        // التحويل إلى السمة الزرقاء (Cyan Theme)
        if (window.tailwind) {
            tailwind.config.theme.extend.colors.brand.emerald = '#06b6d4';
        }
        document.querySelectorAll('.text-emerald-400').forEach(el => el.classList.replace('text-emerald-400', 'text-cyan-400'));
        document.querySelectorAll('.bg-emerald-500').forEach(el => el.classList.replace('bg-emerald-500', 'bg-cyan-500'));
        currentTheme = 'cyan';
    } else {
        // العودة إلى السمة الزمردية (Emerald Theme)
        if (window.tailwind) {
            tailwind.config.theme.extend.colors.brand.emerald = '#10b981';
        }
        document.querySelectorAll('.text-cyan-400').forEach(el => el.classList.replace('text-cyan-400', 'text-emerald-400'));
        document.querySelectorAll('.bg-cyan-500').forEach(el => el.classList.replace('bg-cyan-500', 'bg-emerald-500'));
        currentTheme = 'emerald';
    }
}
