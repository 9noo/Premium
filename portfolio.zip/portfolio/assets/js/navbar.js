// --- Navbar.js ---
export function initNavbar() {
    const header = document.getElementById('main-header');
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    // تأثير الـ Scroll وتغيير شفافية الـ Header
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('glass', 'shadow-lg', 'border-b', 'border-white/5');
            header.querySelector('.max-w-7xl').classList.replace('h-20', 'h-16');
        } else {
            header.classList.remove('glass', 'shadow-lg', 'border-b', 'border-white/5');
            header.querySelector('.max-w-7xl').classList.replace('h-16', 'h-20');
        }
    });

    // تبديل ظهور قائمة الهواتف
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });

    // غلق القائمة فور الضغط على أي رابط
    document.querySelectorAll('.mobile-nav-link').forEach(link => {
        link.addEventListener('click', () => {
            mobileMenu.classList.add('hidden');
        });
    });
}
