// --- modal.js ---
import { projectsData } from '../data/projects.js';

const modal = document.getElementById('project-modal');
const modalBox = modal ? modal.querySelector('.transform') : null;

export function openModal(projectId) {
    const project = projectsData.find(p => p.id === projectId);
    if (!project || !modal) return;

    // حقن البيانات والـ content داخل المودال
    document.getElementById('modal-title').textContent = project.title;
    document.getElementById('modal-badge').textContent = project.category === 'python' ? 'بايثون وأتمتة' : project.category === 'customization' ? 'تخصيص الأنظمة' : 'تطوير ويب';
    document.getElementById('modal-description').textContent = project.fullDescription;

    // حقن قائمة الميزات والخصائص
    const featuresList = document.getElementById('modal-features-list');
    const featuresContainer = document.getElementById('modal-features-container');
    
    if (project.features && project.features.length > 0) {
        featuresContainer.classList.remove('hidden');
        featuresList.innerHTML = project.features.map(f => `<li class="flex items-start gap-2"><span class="text-emerald-500">◀</span><span>${f}</span></li>`).join('');
    } else {
        featuresContainer.classList.add('hidden');
    }

    // حقن التقنيات
    const techTags = document.getElementById('modal-tech-tags');
    techTags.innerHTML = project.tech.map(t => `<span class="text-xs font-mono px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/5 text-gray-300">${t}</span>`).join('');

    // تحديث الروابط الخارجية
    const liveLink = document.getElementById('modal-live-link');
    const codeLink = document.getElementById('modal-code-link');

    if (project.liveUrl && project.liveUrl !== '#') {
        liveLink.href = project.liveUrl;
        liveLink.classList.remove('hidden');
    } else {
        liveLink.classList.add('hidden');
    }

    if (project.codeUrl) {
        codeLink.href = project.codeUrl;
        codeLink.classList.remove('hidden');
    } else {
        codeLink.classList.add('hidden');
    }

    // تفعيل المؤثرات البصرية للفتح (Fade In + Scale Up)
    modal.classList.remove('pointer-events-none', 'opacity-0');
    modalBox.classList.remove('scale-95');
    modalBox.classList.add('scale-100');
    document.body.classList.add('overflow-hidden'); // منع السكرول خلف المودال
}

export function closeModal() {
    if (!modal) return;
    
    modal.classList.add('opacity-0', 'pointer-events-none');
    modalBox.classList.remove('scale-100');
    modalBox.classList.add('scale-95');
    document.body.classList.remove('overflow-hidden');
}

// تهيئة مستمعي الأحداث لإغلاق المودال بدون Inline JS
export function initModal() {
    const closeBtn = document.getElementById('close-modal-btn');
    if (!modal || !closeBtn) return;

    // الإغلاق عند الضغط على زر X
    closeBtn.addEventListener('click', closeModal);

    // الإغلاق عند الضغط خارج المودال (الخلفية الداكنة)
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // الإغلاق عند الضغط على زر Escape في الكيبورد
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
}
