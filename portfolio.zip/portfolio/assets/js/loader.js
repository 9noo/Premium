// --- Loader.js ---
export function initLoader() {
    const loader = document.getElementById('loader');
    const progressBar = document.getElementById('loader-progress');
    const percentageText = document.getElementById('loader-percentage');
    
    let progress = 0;
    
    const interval = setInterval(() => {
        progress += Math.floor(Math.random() * 15) + 5; // تقدم عشوائي لواقعية أكثر
        
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            
            // انتهاء التحميل وتأثير الخروج
            setTimeout(() => {
                loader.classList.add('opacity-0', 'pointer-events-none');
                document.body.classList.remove('overflow-hidden');
            }, 500);
        }
        
        progressBar.style.width = `${progress}%`;
        percentageText.textContent = `${progress}%`;
    }, 100);
    
    // قفل الاسكرول أثناء التحميل
    document.body.classList.add('overflow-hidden');
}
