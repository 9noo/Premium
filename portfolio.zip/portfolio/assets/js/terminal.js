// --- terminal.js ---

// تعريف الأوامر المتاحة والردود المخصصة لها
const COMMANDS = {
    help: `
Available commands:
  <span class="text-emerald-400">about</span>        - Summary of who Nour is.
  <span class="text-emerald-400">skills</span>       - Show technical skill percentages.
  <span class="text-emerald-400">projects</span>     - List key completed projects.
  <span class="text-emerald-400">cool-pc</span>      - Simulate hardware fan speed and thermal cooling analysis.
  <span class="text-emerald-400">bypass-ig</span>    - Simulate MetaConfig flags patch for Instagram quality.
  <span class="text-emerald-400">mtz-builder</span>  - Simulate merging .ttf fonts into HyperOS/MIUI .mtz theme.
  <span class="text-emerald-400">clear</span>        - Clear terminal screen.
  <span class="text-emerald-400">social</span>       - Display active social connections.
`,
    about: `
<span class="text-cyan-400">Name:</span> Nour El-Din
<span class="text-cyan-400">Location:</span> Baghdad, Iraq
<span class="text-cyan-400">Role:</span> Technical Student & Developer
<span class="text-cyan-400">Bio:</span> Software automater, custom themes designer, and hardware optimizer. Passionate about Python, automation, and bypassing media compression algorithms.
`,
    skills: `
<span class="text-purple-400">Technical Skill Matrix:</span>
  - Python / Bot Development  [██████████████░░░] 85%
  - Excel Automations         [███████████████░░] 90%
  - Frontend Engineering      [██████████████░░░] 80%
  - Thermal System Tuning     [████████████░░░░░] 75%
  - Custom Android MTZ Themes [██████████████░░░] 85%
`,
    projects: `
<span class="text-yellow-400">Recent Innovations:</span>
  1. <span class="text-white">MIUI Font Merger (.mtz)</span> - Integrates TTF fonts for Xiaomi themes.
  2. <span class="text-white">Telegram Inline Bot</span> - Python bot utilizing advanced inline control boards.
  3. <span class="text-white">Excel Auto Sorter</span> - Python script transforming large scale data pipelines.
  4. <span class="text-white">Instagram Quality Bypass</span> - MetaConfig flags optimization pipeline.
`,
    social: `
<span class="text-emerald-400">Find me on:</span>
  - Telegram:   <a href="https://t.me" target="_blank" class="text-cyan-400 underline">@Nour_Eldin</a>
  - GitHub:     <a href="https://github.com" target="_blank" class="text-cyan-400 underline">nour-github</a>
  - Instagram:  <a href="https://instagram.com" target="_blank" class="text-cyan-400 underline">Nour_Profile</a>
`
};

export function initTerminal() {
    const input = document.getElementById('terminal-input');
    const body = document.getElementById('terminal-body');

    if (!input || !body) return;

    // استماع للضغط على زر Enter لإرسال الأمر
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const commandText = input.value.trim().toLowerCase();
            input.value = ''; // تفريغ المدخلات فوراً

            if (commandText === '') return;

            handleCommand(commandText);
        }
    });

    // دالة معالجة الأوامر
    function handleCommand(cmd) {
        // 1. طباعة الأمر المدخل أولاً في الهيستوري
        writeLine(`<span class="text-emerald-500 font-bold">nour@baghdad:~$</span> <span class="text-white">${cmd}</span>`);

        // 2. تحليل الأوامر والردود عليها
        if (cmd === 'clear') {
            body.innerHTML = '';
            return;
        }

        if (COMMANDS[cmd]) {
            writeLine(COMMANDS[cmd]);
            return;
        }

        // 3. الأوامر التفاعلية الخاصة (Simulations)
        if (cmd === 'cool-pc') {
            simulateCooling();
            return;
        }

        if (cmd === 'bypass-ig') {
            simulateInstagramBypass();
            return;
        }

        if (cmd === 'mtz-builder') {
            simulateMtzMerge();
            return;
        }

        // في حال إدخال أمر غير معروف
        writeLine(`<span class="text-red-500">Command not found: "${cmd}". Type "help" to see available options.</span>`);
    }

    // دالة مساعدة لطباعة سطر جديد مع سكرول تلقائي لأسفل الطرفية
    function writeLine(htmlContent, delay = 0) {
        const line = document.createElement('div');
        line.innerHTML = htmlContent;
        body.appendChild(line);
        body.scrollTop = body.scrollHeight; // النزول لآخر سطر تلقائياً
    }

    // --- 1. محاكاة تبريد الحاسوب ولاب توب الألعاب (Hardware Cooling Simulation) ---
    function simulateCooling() {
        writeLine(`<span class="text-cyan-400">[SYSTEM] Hooking into motherboard sensors...</span>`);
        
        let steps = [
            { text: "Reading current CPU & GPU temperatures...", delay: 600 },
            { text: "<span class='text-red-400'>Warning: Core temp detected at 87°C (Thermal Throttling risk).</span>", delay: 1200 },
            { text: "Boosting cooling pad system fan speed to max RPM...", delay: 2000 },
            { text: "<span class='text-yellow-400'>Fan Speed: 4800 RPM (Active) | Power Level: 100%</span>", delay: 2800 },
            { text: "Applying hardware power limit optimizations (Undervolting)...", delay: 3600 },
            { text: "<span class='text-emerald-400'>Temperature stabilized! CPU: 64°C | GPU: 61°C. Smooth FPS locked.</span>", delay: 4500 }
        ];

        steps.forEach(step => {
            setTimeout(() => {
                writeLine(step.text);
            }, step.delay);
        });
    }

    // --- 2. محاكاة تجاوز ضغط الإنستغرام (MetaConfig Bypass Simulation) ---
    function simulateInstagramBypass() {
        writeLine(`<span class="text-yellow-500">[BYPASS] Loading MetaConfig application interceptor...</span>`);

        let steps = [
            { text: "Locating config/developer_options.json in app sandbox...", delay: 600 },
            { text: "Injecting flag: <span class='text-cyan-400'>image_quality_bonus = true</span>", delay: 1300 },
            { text: "Injecting flag: <span class='text-cyan-400'>video_upload_bitrate_target_fps = 60</span>", delay: 2000 },
            { text: "Disabling default client-side visual compression algorithm...", delay: 2800 },
            { text: "<span class='text-emerald-400'>[SUCCESS] MetaConfig Patched successfully! Ready to upload Ultra-HD media without compression loss.</span>", delay: 3800 }
        ];

        steps.forEach(step => {
            setTimeout(() => {
                writeLine(step.text);
            }, step.delay);
        });
    }

    // --- 3. محاكاة دمج الخطوط وصنع ثيم شاومي (MIUI/HyperOS Theme builder Simulation) ---
    function simulateMtzMerge() {
        writeLine(`<span class="text-purple-400">[MERGER] Starting custom font-face builder...</span>`);

        let steps = [
            { text: "Parsing system Arabic.ttf and English.ttf glyph metrics...", delay: 600 },
            { text: "Adjusting font ascent/descent properties to prevent text clipping...", delay: 1400 },
            { text: "Merging files into: <span class='text-yellow-400'>NourCustomFont.ttf</span> (Successfully built)", delay: 2200 },
            { text: "Packaging MIUI theme file hierarchy and writing description.xml...", delay: 3000 },
            { text: "Encrypting and exporting package to: <span class='text-cyan-400'>NourTheme_v2.mtz</span>", delay: 3800 },
            { text: "<span class='text-emerald-400'>[SUCCESS] Theme compiled! Move 'NourTheme_v2.mtz' to InternalStorage/Themes to apply on MIUI/HyperOS.</span>", delay: 4600 }
        ];

        steps.forEach(step => {
            setTimeout(() => {
                writeLine(step.text);
            }, step.delay);
        });
    }
}
