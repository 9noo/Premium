// --- App.js ---
import { initLoader } from './loader.js';
import { initThemeSystem } from './theme.js';
import { initCursorGlow } from './cursor.js';
import { initNavbar } from './navbar.js';
import { initTypingEffect, initScrollReveal } from './animation.js';
import { initStatsCounter } from './stats.js';
import { initSkillsAnimation } from './skills.js';
import { initProjects } from './projects.js';
import { initModal } from './modal.js';
import { initTerminal } from './terminal.js';

// استيراد المرحلة الخامسة والأخيرة
import { initContactForm } from './contact.js';

document.addEventListener('DOMContentLoaded', () => {
    // 1. تشغيل نظام التحميل التمهيدي والـ Loader
    initLoader();
    
    // 2. تشغيل المظهر والأنظمة البصرية والـ Glow
    initThemeSystem();
    initCursorGlow();
    initNavbar();
    
    // 3. تشغيل الحركات النصية والظهور المتدرج للأقسام
    initTypingEffect();
    initScrollReveal();
    
    // 4. تشغيل عداد الإحصائيات ورسوم المهارات التفاعلية
    initStatsCounter();
    initSkillsAnimation();

    // 5. تشغيل معرض المشاريع والمودال الموحد (المرحلة الثالثة)
    initProjects();
    initModal();

    // 6. تشغيل محاكي الطرفية التفاعلي (المرحلة الرابعة)
    initTerminal();

    // 7. تشغيل معالجة فورم الاتصال الذكي (المرحلة الخامسة)
    initContactForm();
});
