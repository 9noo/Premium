// --- contact.js ---

export function initContactForm() {
    const form = document.getElementById('contact-form');
    const submitBtn = document.getElementById('submit-btn');
    const btnText = document.getElementById('btn-text');
    const btnSpinner = document.getElementById('btn-spinner');
    const formAlert = document.getElementById('form-alert');

    if (!form || !submitBtn) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // 1. استخراج قيم الحقول وتطهيرها
        const name = document.getElementById('name').value.trim();
        const contactMethod = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();

        // 2. التحقق من صحة الحقول برمجياً
        if (name === '' || contactMethod === '' || message === '') {
            showAlert('يرجى ملء جميع الحقول المطلوبة قبل الإرسال.', 'error');
            return;
        }

        // 3. تحويل الزر إلى حالة "جاري التحميل"
        setLoading(true);

        try {
            // محاكاة عملية إرسال ذكية تضمن ظهور الأنميشن بسلاسة (مدة ثانيتين)
            // يمكنك مستقبلاً استبدال هذا بربط حقيقي مع الـ API الخاص بك مثل:
            /*
            const response = await fetch('https://api.web3forms.com/submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    access_key: "YOUR_ACCESS_KEY_HERE",
                    name,
                    email: contactMethod,
                    message
                })
            });
            */
            await new Promise(resolve => setTimeout(resolve, 2000));

            // 4. عرض حالة النجاح وتصفير الفورم
            showAlert('تم إرسال رسالتك بنجاح يا بطل! سيتواصل معك نور الدين قريباً جداً.', 'success');
            form.reset();

        } catch (error) {
            showAlert('حدث خطأ أثناء محاولة الإرسال، يرجى المحاولة مرة أخرى أو الاتصال بي عبر تليكرام مباشرة.', 'error');
        } finally {
            // 5. استعادة الزر لحالته الطبيعية
            setLoading(false);
        }
    });

    // دالة للتحكم بحالة تحميل الزر
    function setLoading(isLoading) {
        if (isLoading) {
            submitBtn.disabled = true;
            submitBtn.classList.add('opacity-75', 'cursor-not-allowed');
            btnText.classList.add('hidden');
            btnSpinner.classList.remove('hidden');
        } else {
            submitBtn.disabled = false;
            submitBtn.classList.remove('opacity-75', 'cursor-not-allowed');
            btnText.classList.remove('hidden');
            btnSpinner.classList.add('hidden');
        }
    }

    // دالة مخصصة لعرض التنبيهات وتلوينها وإخفائها بعد 5 ثوانٍ بتأثير ناعم
    function showAlert(text, type) {
        formAlert.innerHTML = '';
        formAlert.classList.remove('hidden', 'bg-emerald-500/10', 'border-emerald-500/20', 'text-emerald-400', 'bg-red-500/10', 'border-red-500/20', 'text-red-400');

        if (type === 'success') {
            formAlert.classList.add('bg-emerald-500/10', 'border', 'border-emerald-500/20', 'text-emerald-400');
            formAlert.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${text}`;
        } else {
            formAlert.classList.add('bg-red-500/10', 'border', 'border-red-500/20', 'text-red-400');
            formAlert.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${text}`;
        }

        formAlert.classList.remove('hidden');

        // إخفاء التنبيه بعد 5 ثوانٍ بشكل تدريجي
        setTimeout(() => {
            formAlert.classList.add('opacity-0');
            setTimeout(() => {
                formAlert.classList.add('hidden');
                formAlert.classList.remove('opacity-0');
            }, 300);
        }, 5000);
    }
}
