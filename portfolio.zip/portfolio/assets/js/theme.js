// --- Theme.js ---
export function initThemeSystem() {
    const themeBtn = document.getElementById('theme-btn');
    
    // مصفوفة الثيمات المدعومة للتنقل بينها
    const themes = [
        { theme: 'dark', accent: 'emerald' },
        { theme: 'dark', accent: 'blue' },
        { theme: 'dark', accent: 'purple' },
        { theme: 'light', accent: 'emerald' }
    ];
    
    // استرجاع الثيم المفضل للمستخدم أو الإعداد الافتراضي
    let currentThemeIndex = parseInt(localStorage.getItem('user-theme-index')) || 0;
    applyTheme(themes[currentThemeIndex]);

    themeBtn.addEventListener('click', () => {
        currentThemeIndex = (currentThemeIndex + 1) % themes.length;
        applyTheme(themes[currentThemeIndex]);
        localStorage.setItem('user-theme-index', currentThemeIndex);
    });

    function applyTheme({ theme, accent }) {
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.setAttribute('data-accent', accent);
    }
}
